export const carouselImagesPersonal = [
    "https://ramad.bog.ge/s3/sso/images/584d8587-42e1-41da-957c-74a0c3fc88ba.jpg",
    "https://ramad.bog.ge/s3/sso/images/f02c01d4-52f7-4d23-a579-8860e8360ac1.jpg",
    "https://ramad.bog.ge/s3/sso/images/41088856-e13c-49aa-882d-232a64b62b92.jpg",
    "https://ramad.bog.ge/s3/sso/images/f9148125-a793-4931-96fb-0d4ed6dd4fd7.png",
    "https://ramad.bog.ge/s3/sso/images/8cfea31a-c0d6-4f67-9828-bcd878e2b622.png",
    "https://ramad.bog.ge/s3/sso/images/50fd36ba-df98-4d2f-bf7f-95fc0205537c.jpg",
    "https://ramad.bog.ge/s3/sso/images/4ac3d575-8ec8-43f8-af56-ef0c934898b8.png"
]

export const carouselImagesBusiness = [
    "https://ramad.bog.ge/s3/sso/images/ebfa548b-9e60-427c-9b43-99afdd6fd1bf.jpg",
    "https://ramad.bog.ge/s3/sso/images/a803b355-860d-4d44-87b2-6018dc9b8aaf.jpg"
]

export const carouselImagesManager = [
    "https://ramad.bog.ge/s3/apimarketplace/images/c78a0eb7-d60c-4e84-83e2-04e1714eddd8.png"
]