export type LoginPath = "/personal" | "/business" | "/manager"
