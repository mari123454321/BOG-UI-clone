export const digitalChanelsinfo = {
    title: "Digital channels",
    content: ["Internet Bank", "Business Internet Bank", "Business Manager", "Payments"],
    color: ["#ff600a", "#5a646f", "#1a1a1a", "#ff8b66"]
}