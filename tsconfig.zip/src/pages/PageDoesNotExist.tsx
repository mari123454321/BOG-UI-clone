export default function PageDoesNotExist(){
    return(
        <h1>
            Page Does Not Exist
        </h1>
    )
}