export default function ComingSoon() {
    return (
        <div style={{ padding: "3rem", textAlign: "center", fontSize: "1.5rem" }}>
            <h2>Coming Soon</h2>
            <p>This page is under development</p>
        </div>
    )
}